# Lyra for your computer

The Linux preview is built for x86-64 computers and tested on Ubuntu 24.04.
Extract the archive, keep its files together, and open `lyra` inside the folder.
You can also run `./lyra` from a terminal in that folder. A graphical desktop
with GTK 3 and OpenGL support is required.

Import a PDF with selectable text, choose your size, and follow the rows. Notes,
corrections, photos from files and project exports work locally. Export from your
phone as `.knit.zip` and import that file on your computer to move a project.
Changes do not automatically sync between devices. Keep an exported backup before
updating; replacing the application folder does not remove your saved projects.

Desktop exports use a Save As dialog. To receive a Wi-Fi transfer, type the pairing
code shown by the other device. Camera scanning and home-screen widgets are phone
features. OCR for scanned PDFs currently runs on Android/iOS; import a scan on your
phone and transfer the resulting project to your computer. Spoken instructions
depend on platform support and are not available in this Linux preview.

A separate Windows x64 preview is available as a portable ZIP; see
[Windows instructions](WINDOWS.md). Its native tests and packaged application
launch passed on the private Windows CI runner.
