# Constellation catalogue sources and attribution

Lyra offers all **88 IAU constellations**, including the **12 traditional zodiac
figures**. IAU constellations are bounded sky regions; connecting stars into
stick figures is a separate convention. Ophiuchus exists in the full catalogue
but is not labelled as one of the traditional twelve zodiac figures.

## Sources and licences

- Names, English meanings, abbreviations and links to official boundary files:
  [International Astronomical Union: The Constellations](https://iauarchive.eso.org/public/themes/constellations/).
  These short factual labels are used as metadata; IAU chart artwork is not copied.
- Additional stick-figure connections: **Stellarium team**, modern sky culture,
  [index.json](https://github.com/Stellarium/stellarium/blob/59ddc411d3a8b0d8691cb4538d38310763cbdb4c/skycultures/modern/index.json).
  [The source description/license](https://github.com/Stellarium/stellarium/blob/59ddc411d3a8b0d8691cb4538d38310763cbdb4c/skycultures/modern/description.md)
  licenses text and data under **CC BY-SA 4.0**. No constellation illustrations
  are copied (those have a separate Free Art License).
- Star positions, visual magnitudes and proper names: **David Nash / Astronexus,
  HYG Database v4.0**, [pinned source](https://github.com/astronexus/HYG-Database/blob/c7f7f883fe678cc7680169a50ccd7dcc49b060ce/hyg/CURRENT/hygdata_v40.csv.gz),
  [license](https://github.com/astronexus/HYG-Database/blob/c7f7f883fe678cc7680169a50ccd7dcc49b060ce/LICENSE),
  **CC BY-SA 4.0**. HYG combines Hipparcos, Yale Bright Star and Gliese catalogues.
  The author's current home is https://codeberg.org/astronexus/hyg; this build uses
  the pinned version above for reproducibility.

The generated adapted data in `lib/sky/constellation_catalogue.g.dart` is supplied
under [Creative Commons Attribution-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-sa/4.0/).
The credits and licence link are also available in each figure's in-app details.
There is no implication of endorsement by the IAU, Stellarium or Astronexus.

## Transformations and compatibility

- The original 18 figure IDs, star positions, lines and default project assignment
  are retained unchanged. Seventy figures are added; metadata covers all 88.
- Each new Stellarium line endpoint is an actual HIP identifier found in HYG.
  No missing stars were interpolated or invented. HYG right ascension in hours
  is converted to degrees by multiplying by15; declination and visual magnitude
  are carried through. Stars without proper names display their HIP identifier.
- Duplicate undirected line segments are removed; all supplied connected
  components remain. Serpens therefore retains its separate sections.
- Gnomonic projection is performed by the existing renderer. The result is a
  stylized star figure, not a boundary map or a viewing-time recommendation.
- Northern/southern filters use the mean declination of the source stick-figure
  stars. They describe the figure's location, not full IAU boundary extents or
  visibility from a user's location. Zodiac uses Stellarium's traditional list.
- Short Portuguese meanings are Lyra translations of factual descriptions;
  Latin constellation names remain shared across interface languages.

## Regeneration

Download the four pinned/official files into a local source directory named
`modern.json`, `modern-description.md`, `hyg.csv.gz`, and `iau.html`. Run:

```sh
python3 tool/generate_constellations.py /path/to/source-directory
 dart format lib/sky/constellation_catalogue.g.dart
```

The generator uses Python's standard library plus BeautifulSoup for the IAU table.
Raw HYG and IAU files are not bundled with the app. Source retrieval date:
19 September2026. SHA256 of the inputs used:

| File | SHA256 |
|---|---|
| `modern.json` | `1f2f5ffd6c9e25a7d0dcfdbf1f756e2db03dd3b8ed4ec016a2839b09f6b0fe1e` |
| `modern-description.md` | `4b58344f63168d7c816fdfef405103b5770fda2e1f4a4bf5c8871041ce042586` |
| `hyg.csv.gz` | `8e3ff9e67445e558a759b117910850cff1b1d4d492f45f715c2ee2db3d869bac` |
| `iau.html` | `bdd1ddc5215aece2c8d54df5e2682a9fc032b176ced8262776e975896d4a9c88` |
